/* Finding mean time spent by each client*/
select Variation,AVG(Cast(timespentperclient as Float))/60 from
	(
		select client_id,Variation, sum(cast(timespentpersession as float)) as timespentperclient from
		(

			select a.client_id,a.Variation,visit_Id, datediff(second,Min(date_time),Max(date_time)) as timespentpersession
			from [AB Testing].dbo.df_final_experiment_clients a inner join [AB Testing].dbo.df_final_web_data_pt_1 b
			on a.client_id=b.client_id
			group by a.client_id,a.Variation,visit_Id
		) Temp_table1	
		group by client_id,Variation
	) temp_table2
Group by Variation




/* Finding  average number of session- For clients who completed the process*/
select Variation,AVG(Cast(visits as Float)) from
		(
		select a.client_id,a.Variation, count(distinct visit_id) as visits
		from [AB Testing].dbo.df_final_experiment_clients a inner join [AB Testing].dbo.df_final_web_data_pt_1 b
		on a.client_id=b.client_id
		where a.client_id in 
			(select client_id
			from [AB Testing].dbo.df_final_web_data_pt_1 
			where process_step='confirm'
			)
		group by a.client_id,a.Variation) Temp_table
group by Variation



/* Finding mean time spend in each session - For clients who completed the process*/
select Variation,AVG(Cast(Timespent as Float))/60 from
	(
	select client_id,Variation,visit_Id, DATEDIFF(second,Mindate, Maxdate) Timespent 
	from
		(
		select a.client_id,a.Variation,visit_Id, Max(date_time) Maxdate,Min(date_time) Mindate 
		from [AB Testing].dbo.df_final_experiment_clients a inner join [AB Testing].dbo.df_final_web_data_pt_1 b
		on a.client_id=b.client_id
		where a.client_id in 
				(
				select client_id
				from [AB Testing].dbo.df_final_web_data_pt_1 
				where process_step='confirm'
				)
		group by a.client_id,a.Variation,visit_Id) Temp_table
	) Temp_table1
Group by Variation



/* Finding  mean time spent by client - For clients who completed the process*/
select Variation, avg(Cast(sum_of_time as Float))/60
from 
	(select client_id,Variation,Sum(Cast(Timespent as Float)) sum_of_time from
		(
		select a.client_id,a.Variation,visit_Id, Max(date_time) Maxdate,Min(date_time) Mindate ,DATEDIFF(second, Min(date_time), Max(date_time)) Timespent 
		from [AB Testing].dbo.df_final_experiment_clients a inner join [AB Testing].dbo.df_final_web_data_pt_1 b
		on a.client_id=b.client_id
		where a.client_id in 
				(
				select client_id
				from [AB Testing].dbo.df_final_web_data_pt_1 
				where process_step='confirm'
				)
		group by a.client_id,a.Variation,visit_Id) Temp_table
	Group by Variation,client_id
	) Temp_table2
Group by Variation



/* Finding mean end to end turnaround time for each users in both groups - For clients who completed the process*/
select Variation,AVG(Cast(Timespent as Float))/3600 from
		(
		select a.client_id,a.Variation, DATEDIFF(second,Min(date_time), Max(date_time)) Timespent
		from [AB Testing].dbo.df_final_experiment_clients a inner join [AB Testing].dbo.df_final_web_data_pt_1 b
		on a.client_id=b.client_id
		where a.client_id in 
				(
				select client_id
				from [AB Testing].dbo.df_final_web_data_pt_1 
				where process_step='confirm'
				)
		group by a.client_id,a.Variation) Temp_table
Group by Variation

